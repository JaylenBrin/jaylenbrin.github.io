from pymongo import MongoClient 

class CRUD:
    def __init__(self, user, password):
        self.client = MongoClient("localhost", 27017)
        self.database = self.client['aac']
        self.collection = self.database['animals']
        
    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Create error:", e)
                return False
        return False
            
    def read(self, query):
        try:
            results = self.collection.find(query) 
            return list(results)
        except Exception as e:
            print("Read error:", e)
            return []
        
    def update(self, query, new_values):
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print("Update error:", e)
                return 0
        else:
            return 0
        
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print("Delete error:", e)
                return 0
        else:
            return 0